## usethis namespace: start
#' @importFrom Rcpp sourceCpp
#' @useDynLib ScaleSpikeSlab, .registration = TRUE
## usethis namespace: end
NULL
