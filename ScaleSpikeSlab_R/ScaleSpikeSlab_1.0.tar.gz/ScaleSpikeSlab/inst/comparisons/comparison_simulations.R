# Synthetic dataset simulations
rm(list=ls())
# library(ScalableSpikeSlab)
source('/Users/niloybiswas/Google Drive/My Drive/Niloy_Files/github/ScalableSpikeSlab/inst/comparisons/comparison_functions.R')
source('/Users/niloybiswas/Google Drive/My Drive/Niloy_Files/github/ScalableSpikeSlab/R/helper_functions.R')

# # Installing Skinny Gibbs
# install.packages("/Users/niloybiswas/Downloads/UASA_A_1482754_Supplement/Skinny Gibbs/skinnybasad_0.0.1.tar.gz", repos = NULL, type ="source")
library(skinnybasad)

# Editing the skinnybasad:::skinnybasad function for implementation
# Added the line: PACKAGE = "skinnybasad"
skinnybasad <- function (X, E, pr, B0, Z0, nsplit, modif, nburn = 1000, niter = 5000, 
                         printitrsep = 0, maxsize = 1000, a0 = 0.01, b0 = 1) 
  {
  n = as.integer(dim(X)[1])
  p = as.integer(dim(X)[2])
  printitr = 0
  if (printitrsep != 0) 
    printitr = 1
  if (!is.vector(B0)) 
    B0 = rep(0, p)
  if (!is.vector(Z0)) 
    Z0 = rep(0, p)
  del = 0.1
  s1 = max(a0 * p^{
    2 + del
  }/n, 1)
  s0 = b0/n
  res = .C("skinnybasad", as.double(as.vector(X)), as.double(as.vector(E)), 
           as.double(as.vector(B0)), as.double(as.vector(Z0)), as.double(pr), 
           n, p, as.double(s1), as.double(s0), as.integer(nburn), 
           as.integer(niter), as.integer(nsplit), as.integer(modif), 
           as.integer(printitr), as.integer(printitrsep), as.integer(maxsize), 
           outmarZ = double(p), outsize = integer(niter + nburn),
           PACKAGE = "skinnybasad")
  return(list(marZ = res$outmarZ, allsize = res$outsize[nburn:(nburn + 
                                                                 niter)]))
}


library(doParallel)
registerDoParallel(cores = detectCores()-1)
library(foreach)
library(dplyr)
library(ggplot2)
library(latex2exp)
library(reshape2)
library(ggpubr)

# stat_performance_df_new

n <- 100
p <- 1000
s0 <- 5
error_std <- 2
signal <- 'decay'
chain_length <- 1e3
burnin <- 1e2
store <- TRUE
i <- 1

comparison_sims <- function(n_p_error_s0_list,chain_length=1e4,burnin=5e3,no_repeats=1,
                            algos=c('ScalableSpikeSlab', 'Sota', 'SkinnyGibbs'), signal='constant',
                            store=TRUE){
  foreach(n_p_error_s0 = n_p_error_s0_list, .combine = rbind)%:%
    foreach(i = c(1:no_repeats), .combine = rbind)%dopar%{
      n <- n_p_error_s0$n
      p <- n_p_error_s0$p
      error_std <- n_p_error_s0$error_std
      s0 <- n_p_error_s0$s0
      
      logreg_sync_data <- synthetic_data(n, p, s0, type = 'logistic', signal=signal)
      X <- logreg_sync_data$X
      X <- matrix(scale(X), n, p)
      y <- logreg_sync_data$y
      Xt <- t(X)
      signal_indices <- logreg_sync_data$true_beta!=0
      
      params <- spike_slab_params(n, p)
      
      output <- data.frame()
      
      if('ScalableSpikeSlab' %in% algos){
        ###### Scalable spike and slab
        sss_time_taken <-
          system.time(
            sss_chain <- 
              comparison_spike_slab_mcmc(chain_length=chain_length, X=X,Xt=Xt,y=y,
                              tau0=params$tau0, tau1=params$tau1, q=params$q, 
                              a0=params$a0,b0=params$b0, algo='ScalableSpikeSlab', rinit=NULL, verbose=TRUE,
                              store=store))
        if(store){
          delta <- rowSums(sss_chain$z[c(1:(chain_length-1)),]!=sss_chain$z[c(2:chain_length),])
          no_active <- rowSums(sss_chain$z[c(1:chain_length),])
          
          sss_tpr <- mean(colMeans(sss_chain$z[c(burnin:chain_length),signal_indices,drop=FALSE])>0.5)
          sss_fdr <- mean(colMeans(sss_chain$z[c(burnin:chain_length),!signal_indices,drop=FALSE])>0.5)
          sss_mse <- mean((colMeans(sss_chain$beta[c(burnin:chain_length),])-logreg_sync_data$true_beta)^2)
          
          output <- 
            rbind(output, 
                  data.frame(algo='ScalableSpikeSlab', time=as.double(sss_time_taken[1])/chain_length, 
                             tpr=sss_tpr, fdr=sss_fdr, mse=sss_mse, delta_mean=mean(delta), delta_var=var(delta),
                             no_active_mean=mean(delta), no_active_var=var(delta), n=n, p=p, s0, iteration=i))
        } else{
          output <- 
            rbind(output, data.frame(algo='ScalableSpikeSlab', 
                                     time=as.double(sss_time_taken[1])/chain_length, n=n, p=p, s0, iteration=i))
        }
      }
      
      if('Sota' %in% algos){
        sota_time_taken <-
          system.time(
            sota_chain <- 
              comparison_spike_slab_mcmc(chain_length=chain_length, X=X,Xt=Xt,y=y,
                              tau0=params$tau0, tau1=params$tau1, q=params$q, 
                              a0=params$a0,b0=params$b0, algo='Sota', rinit=NULL, verbose=TRUE,
                              store=store))
        if(store){
          delta <- rowSums(sota_chain$z[c(1:(chain_length-1)),]!=sota_chain$z[c(2:chain_length),])
          no_active <- rowSums(sota_chain$z[c(1:chain_length),])
          
          sota_tpr <- mean(colMeans(sota_chain$z[c(burnin:chain_length),signal_indices,drop=FALSE])>0.5)
          sota_fdr <- mean(colMeans(sota_chain$z[c(burnin:chain_length),!signal_indices,drop=FALSE])>0.5)
          sota_mse <- mean((colMeans(sota_chain$beta[c(burnin:chain_length),])-logreg_sync_data$true_beta)^2)
          
          output <- 
            rbind(output, 
                  data.frame(algo='Sota', time=as.double(sota_time_taken[1])/chain_length, 
                             tpr=sota_tpr, fdr=sota_fdr, mse=sota_mse, delta_mean=mean(delta), delta_var=var(delta), 
                             no_active_mean=mean(no_active), no_active_var=var(no_active), n=n, p=p, s0, iteration=i))
        } else{
          output <- 
            rbind(output, 
                  data.frame(algo='Sota', time=as.double(sota_time_taken[1])/chain_length, 
                             n=n, p=p, s0, iteration=i))
        }
      }
      
      if('SkinnyGibbs' %in% algos){
        # Skinny Gibbs: Initializing from the prior
        z <- rbinom(p,1,params$q)
        sigma2 <- 1/rgamma(1,shape = (params$a0/2), rate = (params$b0/2))
        beta <- rnorm(p)
        beta[z==0] <- beta[z==0]*(params$tau0*sqrt(sigma2))
        beta[z==1] <- beta[z==1]*(params$tau1*sqrt(sigma2))
        skinnygibbs_time_taken <-
          system.time(
            skinny_chain <-
              skinnybasad(X,y,params$q,beta,z,nsplit=10,modif=1,nburn=burnin,niter=(chain_length-burnin),printitrsep=1,maxsize=100)
          )
        
        if(store){
          skinny_tpr <- mean(skinny_chain$marZ[signal_indices,drop=FALSE]>0.5)
          skinny_fdr <- mean(skinny_chain$marZ[!signal_indices,drop=FALSE]>0.5)
          skinny_mse <- NA
          output <- 
            rbind(output, 
                  data.frame(algo='SkinnyGibbs', time=as.double(skinnygibbs_time_taken[1])/chain_length, 
                             tpr=skinny_tpr, fdr=skinny_fdr, mse=skinny_mse,
                             delta_mean=NA, delta_var=NA, 
                             no_active_mean=NA, no_active_var=NA, 
                             n=n, p=p, s0, iteration=i))
        } else{
          output <- 
            rbind(output, 
                  data.frame(algo='SkinnyGibbs', time=as.double(skinnygibbs_time_taken[1])/chain_length, 
                             n=n, p=p, s0, iteration=i))
        }
      }
      
      print(n_p_error_s0)
      return(output)
    }
}

######## Fix n vary p: time per iteration simulations ########
s0_seq <- c(seq(10,100,10),seq(200,400,100))
time_comparison_grid <- data.frame(n=10*s0_seq, p=100*s0_seq, error_std=2, s0=s0_seq)
time_comparison_list <- split(time_comparison_grid, 1:nrow(time_comparison_grid))
comparison_vary_p_df1 <-
  comparison_sims(time_comparison_list, chain_length=1e3,burnin=0,no_repeats=1,
                  algos=c('ScalableSpikeSlab', 'SkinnyGibbs'),store=FALSE)

# Running Sota sampler for a smaller number of iterations to calculate avergere
# time per iteration as it is slower and the per iteration cost does not depend 
# on chain state
comparison_vary_p_df2 <- 
  comparison_sims(time_comparison_list,chain_length=1e2,burnin=0,
                  no_repeats=1,algos=c('Sota'),store=FALSE)
comparison_vary_p_df <- rbind(comparison_vary_p_df1, comparison_vary_p_df2)
# save(comparison_vary_p_df, file = '/Users/niloybiswas/Google Drive/My Drive/Niloy_Files/github/ScalableSpikeSlab/inst/comparisons/comparison_vary_p_df.Rdata')
# load('/Users/niloybiswas/Google Drive/My Drive/Niloy_Files/github/ScalableSpikeSlab/inst/comparisons/comparison_vary_p_df.Rdata')
# comparison_vary_p_df1
# Run-time comparison plots
time_df <- 
  comparison_vary_p_df %>% 
  group_by(algo,p) %>% 
  summarise(time=mean(time))
# (time_df%>%filter(algo=='SkinnyGibbs'))$time/(time_df%>%filter(algo=='ScalableSpikeSlab'))$time
# (time_df%>%filter(algo=='Sota'))$time/(time_df%>%filter(algo=='ScalableSpikeSlab'))$time

time_comparison <- ggplot(time_df, aes(x=p, y=time*1000, linetype=algo)) + 
  geom_line(size=1) + xlab(TeX('Dimension $p$')) + ylab(TeX('Time per iteration (ms)')) +
  # scale_y_continuous(limits = c(0,600)) +
  # scale_y_continuous(trans='log10') +
  scale_linetype_manual(name=TeX('Sampler'),
                        breaks = c("ScalableSpikeSlab", "Sota", "SkinnyGibbs"),
                        labels=unname(TeX(c('S^3', 'SOTA', 'Skinny Gibbs'))),
                        values = c('solid','dotted','dashed')) +
  theme_classic(base_size = 10) +
  theme(legend.position = 'bottom', legend.key.width=unit(1,"cm")) +
  guides(linetype=guide_legend(nrow=1,byrow=TRUE))
time_comparison
# ggsave(filename = "/Users/niloybiswas/Dropbox/Apps/Overleaf/fast_spike_slab/images/time_comparison.pdf", plot = time_comparison, width = 4, height = 4.5)


######## Fix n vary p: stat estimation comparison simulations ########
# s0_seq <- seq(10,20,2)
# stat_comparison_grid <- data.frame(n=10*s0_seq, p=100*s0_seq, error_std=2, s0=s0_seq)
stat_comparison_grid <- data.frame(n=100, p=seq(100,1000,100), error_std=2, s0=5)
stat_comparison_list <- split(stat_comparison_grid, 1:nrow(stat_comparison_grid))
stat_comparison_vary_p_df <- 
  comparison_sims(stat_comparison_list, chain_length=5e3, burnin=1e3, algos=c('ScalableSpikeSlab','SkinnyGibbs'), no_repeats=10, signal = 'decay')
# save(stat_comparison_vary_p_df, file = '/Users/niloybiswas/Google Drive/My Drive/Niloy_Files/github/ScalableSpikeSlab/inst/comparisons/stat_comparison_vary_p_df.Rdata')
# load('/Users/niloybiswas/Google Drive/My Drive/Niloy_Files/github/ScalableSpikeSlab/inst/comparisons/stat_comparison_vary_p_df.Rdata')
# 

stat_performance_df <-
  stat_comparison_vary_p_df %>%
  select(algo, tpr, fdr, mse, n, p, iteration) %>%
  melt(id=c('algo','n','p','iteration')) %>%
  group_by(algo,n,p,variable) %>%
  summarise(mean=mean(value), sd =sd(value), no_repeats=n())
tpr_comparison <- 
  ggplot(stat_performance_df %>% filter(variable=='tpr'), aes(x=p, y=mean, linetype=algo)) + 
  geom_line(size=0.5) +
  geom_ribbon(aes(ymin=mean-sd/sqrt(no_repeats), ymax=mean+sd/sqrt(no_repeats),
                  fill=algo),alpha=0.2, colour = NA) +
  xlab(TeX('Dimension $p$')) + ylab(TeX('TPR')) +
  scale_linetype_manual(name=TeX('Sampler'),
                        breaks = c("ScalableSpikeSlab", "SkinnyGibbs"),
                        labels=unname(TeX(c('$S^3$','Skinny Gibbs'))),
                        values = c('solid','dashed')) +
  scale_fill_manual(values = c('black','black', 'black'),guide='none') +
  scale_y_continuous(limits = c(0,1), labels = scales::percent_format(accuracy = 1)) +
  # scale_x_continuous(labels = scales::scientific_format(accuracy = 1)) +
  theme_classic(base_size = 10) +
  theme(legend.position = 'bottom', legend.key.width=unit(1,"cm")) +
  guides(linetype=guide_legend(nrow=1,byrow=TRUE))
tpr_comparison

fdr_comparison <- 
  ggplot(stat_performance_df %>% filter(variable=='fdr'), aes(x=p, y=(mean), linetype=algo)) + 
  geom_line(size=0.5) +
  geom_ribbon(aes(ymin=pmax(mean-sd/sqrt(no_repeats),0), ymax=(mean+sd/sqrt(no_repeats)),
                  fill=algo),alpha=0.2, colour = NA) +
  xlab(TeX('Dimension $p$')) + ylab(TeX('FDR')) +
  scale_linetype_manual(name=TeX('Sampler'),
                        breaks = c("ScalableSpikeSlab", "SkinnyGibbs"),
                        labels=unname(TeX(c('$S^3$','Skinny Gibbs'))),
                        values = c('solid','dashed')) +
  scale_fill_manual(values = c('black','black', 'black'),guide='none') +
  scale_y_continuous(limits = c(0,0.04), labels = scales::percent_format(accuracy = 1)) +
  # scale_x_continuous(labels = scales::scientific_format(accuracy = 1)) +
  theme_classic(base_size = 10) +
  theme(legend.position = 'bottom', legend.key.width=unit(1,"cm")) +
  guides(linetype=guide_legend(nrow=1,byrow=TRUE))
fdr_comparison

tpr_fdr_comparison <- 
  ggarrange(tpr_comparison, fdr_comparison, common.legend = TRUE, legend = "bottom")
tpr_fdr_comparison
# ggsave(filename = "/Users/niloybiswas/Dropbox/Apps/Overleaf/fast_spike_slab/images/tpr_fdr_comparison.pdf", plot = tpr_fdr_comparison, width = 4, height = 4.5)

